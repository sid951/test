'use strict';

const gulp = require('gulp'),
    fs = require('fs'),
    plumber = require('gulp-plumber'),
    minimist = require('minimist');
var gulpif = require('gulp-if');

const options = {
    scssDir: './FabiAnalytics.Web/assets/scss/',
    cssDir: './FabiAnalytics.Web/wwwroot/css/',
    src: function plumbedSrc() {
      return gulp.src.apply(gulp, arguments).pipe(plumber());
    }
};

var builArgs = {
  default: {'env': 'development'}, 
}
builArgs = minimist(process.argv.slice(2), builArgs);

/**
 * Load tasks from the '/tasks' directory.
 */
const watch = require('./tasks/watch')(options);
const sass = require('./tasks/sass')(options, builArgs);

/*-----------------------------------------------
|   SASS
-----------------------------------------------*/
gulp.task('sass', gulp.series('build-sass'));

/* Runs the entire pipeline */
gulp.task(
  'default', 
  gulp.series('sass', gulp.parallel('watch'))
);
'use strict';

const gulp = require('gulp');

function watchTask(options) {
    gulp.task('watch', () => {
        gulp.watch(
            [options.scssDir + '**/*.scss'],
            { delay: 500 }, gulp.series('sass'));
    });

}

module.exports = watchTask;

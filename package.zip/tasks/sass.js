'use strict';

const gulp = require('gulp'),
  autoprefixer = require('gulp-autoprefixer'),
  sass = require('gulp-sass'),
  gulpif = require('gulp-if'),
  cleanCSS = require('gulp-clean-css'),
  plumber = require('gulp-plumber');

function sassTask(options, builArgs) {
    var isProduction = builArgs.env === 'production';

    gulp.task(
        'build-theme',
        function()
        {
            return options
            .src(options.scssDir + 'metronic/**/*.scss')
            .pipe(plumber())
            .pipe(sass.sync({ outputStyle: isProduction ? 'compressed' : 'expanded' }).on('error', sass.logError))
            .pipe(autoprefixer({
                browsers: ['last 5 versions'],
                cascade: false,
            }))
            .pipe(gulpif(isProduction,cleanCSS({debug: true}, (details) => {
            })))
            .pipe(plumber.stop())
            .pipe(gulp.dest(options.cssDir + 'metronic'))
        }
    );

    gulp.task(
        'build-custom',
        function()
        {
            return options
            .src(options.scssDir + 'custom/**/*.scss')
            .pipe(plumber())
            .pipe(sass.sync({ outputStyle: isProduction ? 'compressed' : 'expanded' }).on('error', sass.logError))
            .pipe(autoprefixer({
                browsers: ['last 5 versions'],
                cascade: false,
            }))
            .pipe(gulpif(isProduction,cleanCSS({debug: true}, (details) => {
            })))
            .pipe(plumber.stop())
            .pipe(gulp.dest(options.cssDir + 'custom'))
        }
    );

    gulp.task(
      'build-sass', gulp.series('build-theme','build-custom'));
}

module.exports = sassTask;
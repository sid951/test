import Request from "./Request";
export default class TextRequest extends Request {

}

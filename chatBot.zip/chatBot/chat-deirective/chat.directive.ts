import { environment } from "src/environments/environment";
import { Component } from "@angular/core";
import { Observable, Subject, from } from "rxjs";
@Component({
  selector: "app-chat-boot",
  templateUrl: "./chat.directive.html",
  styleUrls: ["./chat.directive.css"]
})
export class ChatBootComponent {
  public msg: Subject<any> = new Subject();
  public msgArray: Observable<Array<any>> = new Observable<Array<any>>();
  public token = environment.token;
  constructor() {}

  public onChange(target: any) {
    this.msg.next(target.value);
    target.value = "";
  }

  public onMsgReceive(msg: string) {}
}
